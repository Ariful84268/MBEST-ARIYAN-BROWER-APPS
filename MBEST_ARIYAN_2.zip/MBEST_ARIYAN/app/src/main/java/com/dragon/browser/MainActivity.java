package com.dragon.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * MBEST ARIYAN BROWER APPS
 * - উপরে লোগো ও নাম, মাঝে Messenger ব্রাউজার
 * - নিচে Home | Extension | Settings
 * - Extension পেজে + চেপে ZIP যোগ করলে নিচে তালিকায় দেখা যায়
 */
public class MainActivity extends Activity {

    static final String EXT_HOST = "dm.ext";
    private static final String HOME = "https://www.messenger.com";

    private static final int REQ_FILE = 11;
    private static final int REQ_ZIP = 12;
    private static final int REQ_PERM = 13;
    private static final int REQ_STORAGE = 14;

    // state used by Bridge
    Ext ext;
    volatile int curId = 1;
    volatile String curUrl = "";
    volatile String curTitle = "";

    private boolean docStart;
    private String desktopUA;

    private FrameLayout rootFrame;
    private WebView web;
    private ProgressBar progress;
    private ScrollView extScroll;
    private ScrollView setScroll;
    private LinearLayout extList;
    private LinearLayout navBar;
    private LinearLayout extPage;      // এক্সটেনশন খুললে এখানে দেখায় (কোনো dialog নয়)
    private FrameLayout extPageHost;
    private TextView extPageTitle;
    private WebView extWeb;
    private String actionId;           // চেপে ধরা Extension-এর id (মুছা/বন্ধ বাটন দেখায়)
    private Tab[] tabs;
    private int curTab = 0;
    private SharedPreferences sp;
    private boolean desktopOn = true;
    private String defaultUA;

    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;
    private String[] pendingDl;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private final Map<WebView, ScriptHandler> handles = new HashMap<>();
    private final Map<String, BgPage> bgs = new HashMap<>();
    private final ArrayList<WebView> popupViews = new ArrayList<>();
    private final Map<Integer, Pending> pending = new HashMap<>();
    private int respSeq = 0;

    static final class BgPage {
        String extId;
        WebView wv;
        boolean loaded;
        final ArrayList<Runnable> queue = new ArrayList<>();

        void post(Runnable r) {
            if (loaded) r.run();
            else queue.add(r);
        }
    }

    static final class Pending {
        final WeakReference<WebView> wv;
        final int cb;

        Pending(WebView w, int cb) {
            this.wv = new WeakReference<>(w);
            this.cb = cb;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ext = new Ext(this);
        sp = getSharedPreferences("mbest", MODE_PRIVATE);
        desktopOn = sp.getBoolean("desktop", true);

        // Desktop mode ডিফল্টে চালু: Windows Chrome-এর User-Agent
        String def = WebSettings.getDefaultUserAgent(this);
        defaultUA = def;
        Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(def);
        String ver = m.find() ? m.group(1) : "120.0.0.0";
        desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + ver + " Safari/537.36";

        boolean ds = false;
        try {
            ds = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        } catch (Throwable ignored) {
        }
        docStart = ds;

        buildUi();
        setupWebView();
        refreshExtensions();
        web.loadUrl(HOME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (web != null) web.destroy();
        } catch (Exception ignored) {
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (extPage != null && extPage.getVisibility() == View.VISIBLE) {
            closeExtPage();
        } else if (actionId != null) {
            actionId = null;
            refreshExtList();
        } else if (curTab != 0) {
            selectTab(0);
        } else if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            moveTaskToBack(true);
        }
    }

    // ------------------------------------------------------------------ UI

    private static final int C_BG = 0xFF0B0506;
    private static final int C_SURF = 0xFF1A0D0F;
    private static final int C_LINE = 0xFF3A1A1C;
    private static final int C_CRIMSON = 0xFFC8141E;
    private static final int C_EMBER = 0xFFFF4A1C;
    private static final int C_GOLD = 0xFFFFC53D;
    private static final int C_TEXT = 0xFFF3E7E1;
    private static final int C_MUTED = 0xFFA58B86;
    private static final int C_PINK = 0xFFE8516E;
    private static final int C_ROW = 0xFF1C1C1E;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable shape(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable card() {
        GradientDrawable g = shape(C_SURF, 16);
        g.setStroke(dp(1), C_LINE);
        return g;
    }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void styleSwitch(Switch s) {
        int[][] st = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(st, new int[]{C_EMBER, C_MUTED}));
        s.setTrackTintList(new ColorStateList(st, new int[]{0x66FF4A1C, 0x33FFFFFF}));
    }

    private TextView pill(String text, boolean filled, View.OnClickListener l) {
        TextView t = tv(text, 13, filled ? Color.WHITE : C_TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable g = shape(filled ? C_CRIMSON : Color.TRANSPARENT, 20);
        if (!filled) g.setStroke(dp(1), C_LINE);
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void buildUi() {
        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(C_BG);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setFitsSystemWindows(true);

        main.addView(buildHeader(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));

        View accent = new View(this);
        accent.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{C_CRIMSON, C_EMBER, C_GOLD}));
        main.addView(accent, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        progress.setProgressTintList(ColorStateList.valueOf(C_GOLD));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));

        web = new WebView(this);
        buildExtPanel();
        buildSettingsPanel();

        FrameLayout content = new FrameLayout(this);
        content.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(progress, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        content.addView(extScroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(setScroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(extPage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        main.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        main.addView(buildNav(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        rootFrame.addView(main, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootFrame);

        // কীবোর্ড খুললে নিচের বার লুকিয়ে যায়, যাতে মেসেঞ্জারে লেখার জায়গা থাকে
        rootFrame.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect r = new Rect();
            rootFrame.getWindowVisibleDisplayFrame(r);
            int full = rootFrame.getRootView().getHeight();
            boolean kb = full - r.bottom > full * 0.15f;
            navBar.setVisibility(kb ? View.GONE : View.VISIBLE);
        });

        selectTab(0);
    }

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(14), 0, dp(14), 0);
        h.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF1F0709, C_BG}));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setPadding(dp(2), dp(2), dp(2), dp(2));
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.TRANSPARENT);
        ring.setStroke(dp(2), C_EMBER);
        logo.setBackground(ring);
        h.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), 0, 0, 0);

        TextView a = tv("MBEST ARIYAN", 18, C_GOLD, true);
        a.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        a.setLetterSpacing(0.08f);
        a.setSingleLine(true);
        TextView b = tv("BROWER APPS", 11, C_EMBER, true);
        b.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        b.setLetterSpacing(0.3f);
        b.setSingleLine(true);
        t.addView(a);
        t.addView(b);
        h.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return h;
    }

    // ---- নিচের বার: Home | Extension | Settings

    private final class Tab {
        final LinearLayout box;
        final FrameLayout pillBox;
        final ImageView icon;
        final TextView label;

        Tab(int iconRes, String text, final int index) {
            box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            pillBox = new FrameLayout(MainActivity.this);
            icon = new ImageView(MainActivity.this);
            icon.setImageResource(iconRes);
            pillBox.addView(icon, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            box.addView(pillBox, new LinearLayout.LayoutParams(dp(60), dp(30)));
            label = tv(text, 11, C_MUTED, false);
            label.setGravity(Gravity.CENTER);
            box.addView(label, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            box.setOnClickListener(v -> onTab(index));
        }

        void set(boolean on) {
            pillBox.setBackground(on ? shape(0x33FF4A1C, 15) : null);
            icon.setColorFilter(on ? C_EMBER : C_MUTED, PorterDuff.Mode.SRC_IN);
            label.setTextColor(on ? C_GOLD : C_MUTED);
            label.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }

    private View buildNav() {
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.VERTICAL);
        navBar.setBackgroundColor(0xFF120708);

        View line = new View(this);
        line.setBackgroundColor(C_LINE);
        navBar.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        tabs = new Tab[]{
                new Tab(R.drawable.ic_home, "Home", 0),
                new Tab(R.drawable.ic_extension, "Extension", 1),
                new Tab(R.drawable.ic_settings, "Settings", 2)
        };
        for (Tab t : tabs) {
            row.addView(t.box, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        navBar.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));
        return navBar;
    }

    private void onTab(int i) {
        if (i == 0 && curTab == 0 && web != null) web.loadUrl(HOME);
        selectTab(i);
    }

    private void selectTab(int i) {
        curTab = i;
        closeExtPage();
        actionId = null;
        extScroll.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        setScroll.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
        for (int k = 0; k < tabs.length; k++) tabs[k].set(k == i);
        if (i == 1) refreshExtList();
    }

    // ---- Extension পেজ: নিচের শিটের মতো তালিকা (Quetta Extensions-এর ধাঁচে)
    // ফাইলে ট্যাপ = সাথে সাথে খুলে যায় | চেপে ধরে রাখা = মুছুন/বন্ধ বাটন | কোনো পপ-আপ নেই

    private void buildExtPanel() {
        final int W = ViewGroup.LayoutParams.MATCH_PARENT;
        final int H = ViewGroup.LayoutParams.WRAP_CONTENT;

        extScroll = new ScrollView(this);
        extScroll.setBackgroundColor(C_BG);
        extScroll.setFillViewport(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(10), dp(16), dp(24));

        // উপরের ছোট হ্যান্ডেল
        View handle = new View(this);
        handle.setBackground(shape(0xFF5A5A5E, 3));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(40), dp(5));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(handle, hp);

        TextView title = tv("Extensions", 22, C_PINK, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, lp(W, H, 0, 16, 0, 18));

        // যোগ করা Extension-এর তালিকা (এক কার্ডে)
        extList = new LinearLayout(this);
        extList.setOrientation(LinearLayout.VERTICAL);
        extList.setBackground(shape(C_ROW, 28));
        col.addView(extList, lp(W, H, 0, 0, 0, 0));

        // নিচের বাটন: ZIP যোগ করুন
        TextView add = tv("+   Extension যোগ করুন", 17, C_PINK, false);
        add.setGravity(Gravity.CENTER_VERTICAL);
        add.setPadding(dp(24), dp(20), dp(24), dp(20));
        add.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), shape(C_ROW, 28), null));
        add.setOnClickListener(v -> pickZip());
        col.addView(add, lp(W, H, 0, 18, 0, 0));

        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        ImageView fi = new ImageView(this);
        fi.setImageResource(R.drawable.ic_extension);
        fi.setColorFilter(C_MUTED, PorterDuff.Mode.SRC_IN);
        foot.addView(fi, new LinearLayout.LayoutParams(dp(14), dp(14)));
        foot.addView(tv("Powered by MBEST ARIYAN", 13, C_MUTED, false), lp(H, H, 6, 0, 6, 0));
        col.addView(foot, lp(W, H, 0, 22, 0, 0));

        extScroll.addView(col, new ViewGroup.LayoutParams(W, H));

        // Extension খুললে যে পেজ দেখায় (উপরে ← ও নাম, নিচে Extension-এর নিজের পেজ)
        extPage = new LinearLayout(this);
        extPage.setOrientation(LinearLayout.VERTICAL);
        extPage.setBackgroundColor(C_BG);
        extPage.setVisibility(View.GONE);
        extPage.setClickable(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF1A0D0F);
        TextView back = tv("←", 24, C_TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> closeExtPage());
        bar.addView(back, new LinearLayout.LayoutParams(dp(56), W));
        extPageTitle = tv("", 16, C_TEXT, true);
        extPageTitle.setSingleLine(true);
        extPageTitle.setEllipsize(TextUtils.TruncateAt.END);
        bar.addView(extPageTitle, new LinearLayout.LayoutParams(0, H, 1f));
        extPage.addView(bar, new LinearLayout.LayoutParams(W, dp(48)));

        extPageHost = new FrameLayout(this);
        extPage.addView(extPageHost, new LinearLayout.LayoutParams(W, 0, 1f));
    }

    private Bitmap loadIcon(Ext.Info e) {
        try {
            File f = e.iconFile();
            if (f == null) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int max = Math.max(o.outWidth, o.outHeight);
            int sample = 1;
            while (max / (sample * 2) >= 160) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    private void refreshExtList() {
        if (extList == null) return;
        extList.removeAllViews();
        final int W = ViewGroup.LayoutParams.MATCH_PARENT;
        final int H = ViewGroup.LayoutParams.WRAP_CONTENT;
        List<Ext.Info> list = ext.list();
        if (list.isEmpty()) {
            TextView t = tv("এখনো কোনো Extension নেই\nনিচের বাটন চেপে ZIP ফাইল যোগ করুন", 14, C_MUTED, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(20), dp(32), dp(20), dp(32));
            extList.addView(t, new LinearLayout.LayoutParams(W, H));
            return;
        }
        for (final Ext.Info e : list) {
            extList.addView(extRow(e), new LinearLayout.LayoutParams(W, H));
            if (e.id.equals(actionId)) extList.addView(extActions(e), new LinearLayout.LayoutParams(W, H));
        }
    }

    private View extRow(final Ext.Info e) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(16));
        row.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), null, new ColorDrawable(Color.WHITE)));
        row.setAlpha(e.enabled ? 1f : 0.45f);

        ImageView ic = new ImageView(this);
        Bitmap bmp = loadIcon(e);
        if (bmp != null) {
            ic.setImageBitmap(bmp);
            ic.setScaleType(ImageView.ScaleType.FIT_CENTER);
            ic.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(8));
                }
            });
            ic.setClipToOutline(true);
        } else {
            ic.setImageResource(R.drawable.ic_extension);
            ic.setColorFilter(C_GOLD, PorterDuff.Mode.SRC_IN);
            ic.setPadding(dp(6), dp(6), dp(6), dp(6));
            ic.setBackground(shape(0x33FF4A1C, 8));
        }
        row.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(30)));

        TextView name = tv(e.name == null ? "Extension" : e.name, 17, C_TEXT, false);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(name, lp(0, H(), 14, 0, 0, 0));
        ((LinearLayout.LayoutParams) name.getLayoutParams()).weight = 1f;

        // ট্যাপ = সাথে সাথে খুলুন; চেপে ধরা = মুছুন/বন্ধ বাটন দেখান (আবার চাপলে লুকায়)
        row.setOnClickListener(v -> {
            if (actionId != null) {
                actionId = null;
                refreshExtList();
            } else {
                openExtension(e);
            }
        });
        row.setOnLongClickListener(v -> {
            actionId = e.id.equals(actionId) ? null : e.id;
            refreshExtList();
            return true;
        });
        return row;
    }

    private static int H() {
        return ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    /** চেপে ধরলে সারির নিচে দেখায়: বন্ধ/চালু ও মুছুন (কোনো পপ-আপ ছাড়াই) */
    private View extActions(final Ext.Info e) {
        LinearLayout acts = new LinearLayout(this);
        acts.setOrientation(LinearLayout.HORIZONTAL);
        acts.setGravity(Gravity.END);
        acts.setPadding(dp(20), 0, dp(20), dp(14));
        acts.addView(pill(e.enabled ? "বন্ধ করুন" : "চালু করুন", false, v -> {
            ext.setEnabled(e.id, !e.enabled);
            onExtensionsChanged();
        }), lp(H(), H(), 0, 0, 8, 0));
        acts.addView(pill("মুছে ফেলুন", true, v -> {
            ext.delete(e.id);
            onExtensionsChanged();
        }));
        return acts;
    }

    private void openExtension(Ext.Info e) {
        if (!e.enabled) {
            toast("এটি বন্ধ আছে — চেপে ধরে চালু করুন");
            return;
        }
        String p = e.openPath();
        if (p == null) {
            toast("এই Extension-এ খোলার মতো পেজ নেই");
            return;
        }
        showExtPage(e, p);
    }


    // ---- Settings পেজ

    private LinearLayout settingRow(String title, String sub, View trailing, View.OnClickListener click) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), dp(14), dp(16), dp(14));
        r.setBackground(card());
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(tv(title, 16, C_TEXT, true));
        t.addView(tv(sub, 12, C_MUTED, false));
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (trailing != null) r.addView(trailing);
        if (click != null) r.setOnClickListener(click);
        return r;
    }

    private void buildSettingsPanel() {
        setScroll = new ScrollView(this);
        setScroll.setBackgroundColor(C_BG);
        setScroll.setFillViewport(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(24));

        col.addView(tv("Settings", 26, C_TEXT, true));

        Switch sw = new Switch(this);
        styleSwitch(sw);
        sw.setChecked(desktopOn);
        sw.setOnCheckedChangeListener((btn, on) -> {
            desktopOn = on;
            sp.edit().putBoolean("desktop", on).apply();
            web.getSettings().setUserAgentString(on ? desktopUA : defaultUA);
            web.reload();
        });
        final int W = ViewGroup.LayoutParams.MATCH_PARENT;
        final int H = ViewGroup.LayoutParams.WRAP_CONTENT;
        col.addView(settingRow("Desktop mode", "Messenger ডেস্কটপ সাইট হিসেবে খুলবে", sw,
                v -> sw.toggle()), lp(W, H, 0, 18, 0, 10));
        col.addView(settingRow("Messenger রিলোড", "পেজ আবার লোড হবে", null, v -> {
            selectTab(0);
            web.reload();
        }), lp(W, H, 0, 0, 0, 10));
        col.addView(settingRow("Cache ও কুকি মুছুন", "Messenger থেকে লগআউট হয়ে যাবে", null, v ->
                new AlertDialog.Builder(this)
                        .setTitle("Cache ও কুকি মুছবেন?")
                        .setMessage("এতে Messenger থেকে লগআউট হয়ে যাবে।")
                        .setPositiveButton("মুছুন", (d, w) -> clearBrowserData())
                        .setNegativeButton("না", null)
                        .show()), lp(W, H, 0, 0, 0, 10));

        TextView about = tv("MBEST ARIYAN BROWER APPS  •  সংস্করণ 1.0", 12, C_MUTED, false);
        about.setGravity(Gravity.CENTER);
        col.addView(about, lp(W, H, 0, 20, 0, 0));

        setScroll.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void clearBrowserData() {
        web.clearCache(true);
        web.clearHistory();
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        selectTab(0);
        web.loadUrl(HOME);
        toast("মুছে ফেলা হয়েছে");
    }

    // ------------------------------------------------------------------ WebView

    private void setupWebView() {
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        s.setUserAgentString(desktopOn ? desktopUA : defaultUA);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        Bridge br = new Bridge(this, "tab", curId);
        br.attach(web);
        web.addJavascriptInterface(br, "__DM");
        installBootstrap(web, ext.tabBootstrap());

        web.setWebViewClient(new MainClient());
        web.setWebChromeClient(new MainChrome());
        web.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
    }

    private void dropHandle(WebView w) {
        ScriptHandler h = handles.remove(w);
        if (h != null) {
            try {
                h.remove();
            } catch (Throwable ignored) {
            }
        }
    }

    private void installBootstrap(WebView w, String js) {
        dropHandle(w);
        if (!docStart) return;
        try {
            ScriptHandler h = WebViewCompat.addDocumentStartJavaScript(w, js, Collections.singleton("*"));
            handles.put(w, h);
        } catch (Throwable ignored) {
        }
    }

    void openUrlInNewTab(final String url) {
        if (url == null || url.length() == 0) return;
        runOnUiThread(() -> web.loadUrl(url));
    }

    private boolean handleExternal(String u) {
        if (u == null) return false;
        if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("javascript:")
                || u.startsWith("file:")) {
            return false;
        }
        try {
            Intent i;
            if (u.startsWith("intent:")) {
                i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
            } else {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            }
            startActivity(i);
        } catch (Exception e) {
            toast("এই লিংক খোলা গেল না");
        }
        return true;
    }

    private final class MainClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            if (x != null) return x;
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleExternal(r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            curUrl = url == null ? "" : url;
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.tabBootstrap(), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            curUrl = url == null ? "" : url;
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                String u = r.getUrl().toString();
                String page = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:40px 16px;background:#000;color:#ddd'>"
                        + "<h2>পেজ লোড হয়নি</h2><p>ইন্টারনেট চেক করে আবার চেষ্টা করুন।</p>"
                        + "<p style='color:#999;font-size:13px'>" + TextUtils.htmlEncode(String.valueOf(e.getDescription())) + "</p>"
                        + "<button onclick='location.replace(" + TextUtils.htmlEncode(JSONObject.quote(u)) + ")' "
                        + "style='margin-top:14px;padding:12px 28px;border:0;border-radius:12px;background:#1a73e8;color:#fff;font-size:16px'>"
                        + "আবার চেষ্টা</button></body></html>";
                v.loadDataWithBaseURL(u, page, "text/html", "utf-8", u);
            }
        }
    }

    private final class MainChrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            progress.setProgress(p);
            progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            curTitle = title == null ? "" : title;
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> handlePermission(req));
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            rootFrame.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        rootFrame.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ------------------------------------------------------------------ camera / mic

    private void handlePermission(PermissionRequest req) {
        ArrayList<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            req.grant(req.getResources());
            return;
        }
        if (pendingPerm != null) pendingPerm.deny();
        pendingPerm = req;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_STORAGE) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            String[] d = pendingDl;
            pendingDl = null;
            if (ok && d != null) startDownload(d[0], d[1], d[2], d[3]);
            else if (!ok) toast("ডাউনলোড করতে স্টোরেজ পারমিশন লাগবে");
            return;
        }
        if (code != REQ_PERM || pendingPerm == null) return;
        PermissionRequest req = pendingPerm;
        pendingPerm = null;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) req.deny();
        else req.grant(ok.toArray(new String[0]));
    }

    // ------------------------------------------------------------------ download

    private void startDownload(String url, String ua, String cd, String mime) {
        if (url == null) return;
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("এই ধরনের ডাউনলোড সাপোর্ট করে না");
            return;
        }
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDl = new String[]{url, ua, cd, mime};
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && mime.length() > 0) r.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String name = URLUtil.guessFileName(url, cd, mime);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("ডাউনলোড শুরু: " + name);
        } catch (Exception e) {
            toast("ডাউনলোড ব্যর্থ");
        }
    }

    // ------------------------------------------------------------------ Extension button

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        try {
            startActivityForResult(i, REQ_ZIP);
        } catch (Exception e) {
            toast("ফাইল পিকার খোলা গেল না");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        } else if (req == REQ_ZIP) {
            if (res == RESULT_OK && data != null && data.getData() != null) installZip(data.getData());
        }
    }

    private void installZip(final Uri uri) {
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("ফাইল পড়া যায়নি");
                final Ext.Info info;
                try {
                    info = ext.install(in);
                } finally {
                    in.close();
                }
                runOnUiThread(() -> onExtensionsChanged());
            } catch (final Exception e) {
                runOnUiThread(() -> toast("ZIP কাজ করেনি: " + e.getMessage()));
            }
        }).start();
    }

    private void onExtensionsChanged() {
        actionId = null;
        refreshExtensions();
        web.reload();
        refreshExtList();
    }

    /** Rebuilds background pages and re-registers the content-script bootstrap in the page. */
    private void refreshExtensions() {
        for (BgPage b : bgs.values()) {
            rootFrame.removeView(b.wv);
            dropHandle(b.wv);
            try {
                b.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        bgs.clear();
        for (Ext.Info i : ext.list()) {
            if (i.enabled && i.hasBackground()) createBg(i);
        }
        installBootstrap(web, ext.tabBootstrap());
    }

    // ------------------------------------------------------------------ extension pages (background / popup)

    private void configureExtWebView(WebView w, String kind, String extId) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        Bridge br = new Bridge(this, kind, 0);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        installBootstrap(w, ext.pageBootstrap(extId));
    }

    private final class ExtPageClient extends WebViewClient {
        private final String extId;
        private final Runnable onFinish;

        ExtPageClient(String extId, Runnable onFinish) {
            this.extId = extId;
            this.onFinish = onFinish;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            return x != null ? x : super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap f) {
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.pageBootstrap(extId), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (onFinish != null) onFinish.run();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (EXT_HOST.equals(r.getUrl().getHost())) return false;
            openUrlInNewTab(r.getUrl().toString());
            return true;
        }
    }

    private void createBg(Ext.Info i) {
        final BgPage b = new BgPage();
        b.extId = i.id;
        b.wv = new WebView(this);
        configureExtWebView(b.wv, "bg", i.id);
        b.wv.setWebViewClient(new ExtPageClient(i.id, () -> {
            if (!b.loaded) {
                b.loaded = true;
                ArrayList<Runnable> q = new ArrayList<>(b.queue);
                b.queue.clear();
                for (Runnable r : q) r.run();
            }
        }));
        b.wv.setAlpha(0f);
        rootFrame.addView(b.wv, new FrameLayout.LayoutParams(1, 1));
        bgs.put(i.id, b);
        b.wv.loadUrl("https://" + EXT_HOST + Ext.PREFIX + i.id + "/_bg.html");
    }

    private void showExtPage(Ext.Info e, String path) {
        closeExtPage();
        extPageTitle.setText(e.name);
        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        configureExtWebView(w, "popup", e.id);
        w.setWebViewClient(new ExtPageClient(e.id, null));
        popupViews.add(w);
        extWeb = w;
        extPageHost.addView(w, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        extPage.setVisibility(View.VISIBLE);
        w.loadUrl("https://" + EXT_HOST + Ext.PREFIX + e.id + "/" + path);
    }

    private void closeExtPage() {
        if (extWeb != null) {
            WebView w = extWeb;
            extWeb = null;
            popupViews.remove(w);
            if (extPageHost != null) extPageHost.removeView(w);
            dropHandle(w);
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        }
        if (extPage != null) extPage.setVisibility(View.GONE);
    }

    // ------------------------------------------------------------------ message routing (called by Bridge)

    private String senderJson(Bridge from, String extId) {
        JSONObject s = new JSONObject();
        try {
            s.put("id", extId);
            if ("tab".equals(from.kindName())) {
                JSONObject tb = new JSONObject();
                tb.put("id", curId);
                tb.put("url", curUrl == null ? "" : curUrl);
                tb.put("title", curTitle == null ? "" : curTitle);
                s.put("tab", tb);
                s.put("frameId", 0);
                s.put("url", curUrl == null ? "" : curUrl);
            }
        } catch (JSONException ignored) {
        }
        return s.toString();
    }

    void route(final Bridge from, final String extId, final String target, final int destTab,
               final String msg, final int cbId) {
        runOnUiThread(() -> {
            final int rid = ++respSeq;
            pending.put(rid, new Pending(from.webView(), cbId));
            final String sender = senderJson(from, extId);
            if ("bg".equals(target)) {
                final BgPage b = bgs.get(extId);
                if (b == null) {
                    respond(rid, "null");
                    return;
                }
                b.post(() -> deliver(b.wv, extId, msg, sender, rid));
            } else {
                deliver(web, extId, msg, sender, rid);
            }
        });
    }

    private void deliver(WebView dest, String extId, String msg, String sender, final int rid) {
        String js = "(window.__dmDeliver?(window.__dmDeliver(" + JSONObject.quote(extId) + ","
                + JSONObject.quote(msg == null ? "null" : msg) + "," + JSONObject.quote(sender) + "," + rid + "),1):0)";
        dest.evaluateJavascript(js, value -> {
            if (!"1".equals(value)) respond(rid, "null");
        });
    }

    void respond(final int rid, final String json) {
        runOnUiThread(() -> {
            Pending p = pending.remove(rid);
            if (p == null) return;
            WebView w = p.wv.get();
            if (w != null) {
                w.evaluateJavascript("window.__dmCb&&window.__dmCb(" + p.cb + ","
                        + JSONObject.quote(json == null ? "null" : json) + ")", null);
            }
        });
    }

    void broadcastChanges(final String extId, final String changesJson) {
        runOnUiThread(() -> {
            final String js = "window.__dmChanged&&window.__dmChanged(" + JSONObject.quote(extId) + ","
                    + JSONObject.quote(changesJson) + ",'local')";
            web.evaluateJavascript(js, null);
            for (final BgPage b : bgs.values()) b.post(() -> b.wv.evaluateJavascript(js, null));
            for (WebView w : new ArrayList<>(popupViews)) w.evaluateJavascript(js, null);
        });
    }
}
