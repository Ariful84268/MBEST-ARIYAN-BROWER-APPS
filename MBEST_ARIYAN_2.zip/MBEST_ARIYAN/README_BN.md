# MBEST ARIYAN BROWER APPS

- উপরে আপনার লোগো ও লেখা: **MBEST ARIYAN BROWER APPS**
- মাঝে শুধু **Messenger** (messenger.com), Desktop mode ডিফল্টে চালু
- নিচে বার: **Home** | **Extension** | **Settings**
- **Extension** পেজ: নিচের শিটের মতো তালিকা (আইকন + নাম)। নিচের "Extension যোগ করুন" চেপে ZIP দিলে তালিকায় যুক্ত হয়। নামে ট্যাপ করলে সাথে সাথে খোলে (কোনো পপ-আপ নেই)। চেপে ধরে রাখলে নিচে "বন্ধ করুন" ও "মুছে ফেলুন" বাটন আসে
- **Settings**: Desktop mode, Messenger রিলোড, Cache ও কুকি মুছা

## APK বানানো
1. ফোল্ডারটি GitHub repository-তে আপলোড করুন
2. **Actions → Build MBEST ARIYAN APK → Run workflow**
3. শেষে `MBEST-ARIYAN-debug-apk` থেকে `app-debug.apk` নামান

নোট: এই পরিবেশে Android SDK নেই, তাই APK build করে টেস্ট করা যায়নি। build-এ error এলে error লেখাটা পাঠান।
